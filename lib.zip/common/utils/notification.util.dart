// import 'package:flutter/material.dart';
// import "package:flutter_local_notifications/flutter_local_notifications.dart";

// class TestPage extends StatefulWidget {
//   const TestPage({
//     Key? key,
//   }) : super(key: key);

//   @override
//   State<StatefulWidget> createState() => _TestPageState();
// }

// class _TestPageState extends State<TestPage> with WidgetsBinding {
//   @override
//   void initState() {
//     super.initState();
//     WidgetsBinding.instance!.addObserver(this);
//   }

//   @override
//   void dispose() {
//     WidgetsBinding.instance!.removeObserver(this);
//     super.dispose();
//   }

//   @override
//   Widget build(BuildContext ctx) {
//     return MaterialApp();
//   }
// }
